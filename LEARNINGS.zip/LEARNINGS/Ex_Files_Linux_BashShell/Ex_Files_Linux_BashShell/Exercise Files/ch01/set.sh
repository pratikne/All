#!/bin/bash
A=10

