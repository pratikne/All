#!/bin/bash
./set.sh
echo A is $A

