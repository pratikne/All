'''
#Create project hello first from the terminal
C:\Users\pratikne\Desktop\PRATIK AMDOCS\C++ Programs\Django> django-admin startproject hello

cd hello

python manage.py runserver

Visit  http://127.0.0.1:8000/


python .\manage.py startapp myhome
above command creates myhome app within the project. A project should have atleast 1 app

Refer: Code with harry

python manage.py makemigrations
python manage.py migrate 

'''