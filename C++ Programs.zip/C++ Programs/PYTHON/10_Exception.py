
'''
EXCEPTION HANDLING
'''

#Handled in 09_Guess_game.py
#CheckItThere



#Python as scripting language using below modules
'''
1.sys
2.os
3.math
4.datetime
5.random
6.subprocess
7.json
'''

import datetime as dt
print(dt.datetime.today())