#ifndef _CONNECTION_DETAILS
#define _CONNECTION_DETAILS

#define EXAMPLE_DB   "Test"
#define EXAMPLE_HOST "tcp://127.0.0.1:3306"
#define EXAMPLE_USER "pratik"
#define EXAMPLE_PASS "Password"

#endif //_CONNECTION_DETAILS