// C++ Program to demonstrate
// Uninitialized variables
 
#include <iostream>
using namespace std;
 
int main()
{
    bool val;
   
    if (val)
        printf("TRUE");
    else
        printf("FALSE");
}
 