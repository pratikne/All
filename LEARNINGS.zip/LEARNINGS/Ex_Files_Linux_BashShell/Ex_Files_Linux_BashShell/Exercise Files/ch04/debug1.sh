#!/bin/bash
a=1
echo my PID is $$
b=2
echo a is $a b is $b c is $c
if
true
tehn
   echo true is successful
else
   echo true is not successful
fi


