#!/bin/bash
c="ls -s | sort -n"
$c
eval $c
