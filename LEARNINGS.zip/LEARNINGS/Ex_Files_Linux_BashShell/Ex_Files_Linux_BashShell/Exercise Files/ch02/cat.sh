#!/bin/bash
exec 19<data_file
cat 0<&19
cat
 

