import os

print(os.getcwd()) #returns current working dir
os.chdir("C:\\Users\\pratikne\\Desktop\\PRATIK AMDOCS\\C++ Programs") #changes dir
#os.mkdir("New") #creates new dir
os.remove("C:\\Users\\pratikne\\Desktop\\PRATIK AMDOCS\\C++ Programs\\practise.py") #removes file