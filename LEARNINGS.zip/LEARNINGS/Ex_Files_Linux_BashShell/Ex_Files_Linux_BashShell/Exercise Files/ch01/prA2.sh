#!/bin/bash
source ./set.sh
echo A is $A

