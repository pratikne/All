#!/bin/bash
sed 's/ .*$//;1d'

