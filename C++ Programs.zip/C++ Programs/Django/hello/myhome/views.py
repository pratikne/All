from django.shortcuts import render, HttpResponse

# Create your views here.
def index(request):
    context = {
        "variable":"Hi there",
        "var2":"Keep Visiting"
    }
    #return HttpResponse("This is Homepage") #perfectly working
    #return render(request,"index.html") #perfectly working
    return render(request,"index.html",context)

def about(request):
    #return HttpResponse("This is about Homepage")
    return render(request,"about.html")
    
def services(request):
    #return HttpResponse("This is about Homepage services")
    return render(request,"services.html")

def contact(request):
    return HttpResponse("Contact us")
