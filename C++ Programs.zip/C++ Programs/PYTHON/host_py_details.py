import socket
import os

##Python file######
#Home=os.environ['HOME']
Home="/XPISTORAGE/oradp/RV"
CWD=Home + "/SIMULATOR_sanity"
INPUT_path=CWD + "/INPUT"
DWH_path=CWD + "/DWH"
MMS_PY=CWD + "/MMS_USING_BHOLU_SIMULATOR.py"
SMS_PY=CWD + "/SMS_REMOVE_ACCESS.py"
CON_PY=CWD + "/CONTENT.py"
VOICE_PY=CWD + "/VOICE_REMOVE_ACCESS.py"
GPRS_PY=CWD + "/GPRS_REMOVE_ACCESS.py"
WP_PY=CWD + "/TriggerEvents.py"
SOA_DC_PY=CWD + "/SOA_DIA_CHR_REMOVE.py"

#####Host and Ports#######
HOST=socket.gethostname()
MMS_PORT=int(os.environ['MMSC_PORT_100'])
SMS_PORT=int(os.environ['SMSDIAM_PORT_100'])
SOA_Dia_CHR_PORT=int(os.environ['TC1_PORT_SOA_100'])
SOASTACKABLE_PORT=int(os.environ['SOASTACKABLE_PORT_100'])
CONTENT_PORT=int(os.environ['UMB_PORT_100'])
GPRS_PORT=int(os.environ['NEWGGSN_PORT_100'])
VOICE_PORT=int(os.environ['VOCDIAM_PORT_100'])


#####use this when we want use different port###############
#HOST='10.20.233.246'
#$(hostname -i)
#MMS_PORT=35077
#SMS_PORT=34871
#SOA_Dia_CHR_PORT=34873
#SOASTACKABLE_PORT=37129
#CONTENT_PORT=35079
#GPRS_PORT=35090
#VOICE_PORT=35086
