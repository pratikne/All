#!/bin/bash
echo A is $A

