#!/bin/bash
ps -l

