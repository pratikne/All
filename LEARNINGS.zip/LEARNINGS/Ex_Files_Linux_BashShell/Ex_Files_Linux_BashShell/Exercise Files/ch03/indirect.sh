#!/bin/bash
x=abc
abc="Start Of Alphabet"
echo x is $x
echo abc is $abc
echo '${!x}' is ${!x}

