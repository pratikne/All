import sys

print(sys.version) #3.10.6 --- gives python version installed in the system

print(sys.argv)  #returns list of arguments passed to script
print(sys.argv[1]) #returns argument passed at 1st index i.e 2nd argument..1st argument is always file 

