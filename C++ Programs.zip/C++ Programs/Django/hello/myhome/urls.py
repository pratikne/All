
from django.contrib import admin
from django.urls import path
from myhome import views  #added views.py from my app

urlpatterns = [
    #URL Dispatching
    #path('admin/', admin.site.urls), 
    path("",views.index,name='myhome'), #Blank matches, go to views.index function and execute it
    path("about",views.about,name='about'), #Blank matches, go to views.about function and execute it
    path("services",views.services,name='services'), #Blank matches, go to views.services function and execute it
    path("contact",views.contact,name='contact'), #Blank matches, go to views.contact function and execute it

]
