if 
test $1 -gt 5
then
echo greater
else
echo lesser
fi

