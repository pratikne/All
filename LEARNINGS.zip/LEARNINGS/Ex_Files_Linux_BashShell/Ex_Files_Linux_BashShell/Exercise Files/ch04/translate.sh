#!/bin/bash
declare -l line
while
  read line
do
  echo $line
done

  
