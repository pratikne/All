#/bin/bash
((n=2**3 + 5))
echo n = $n
((y=n^4))
echo y = $y  


