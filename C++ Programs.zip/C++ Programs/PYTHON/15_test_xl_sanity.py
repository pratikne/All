#########scripts for running events for Sanity XL COM ###################
import ntpath
import shutil
import os
import csv
import random
from host_py_details import * #importing host and port details from host_py_details.py
from datetime import datetime, timedelta #importing datetime module
import time
import sys
#import datetime

####color the text##########
def prRed(skk): print("\033[91m {}\033[00m" .format(skk))
def prGreen(skk): print("\033[92m {}\033[00m" .format(skk))
def prYellow(skk): print("\033[93m {}\033[00m" .format(skk))
def prPurple(skk): print("\033[95m {}\033[00m" .format(skk))

######Function for checking port ##################
def check_port(EVENT,HOST,PORT):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex((HOST,PORT))
        if result == 0:
                prGreen(EVENT + " Port is listening")
                #print EVENT + " Port is listening"
        else:
                prRed(EVENT +" Port is not listening!!!")
                #print EVENT + " Port is not listening!!!"
        sock.close()





#Getting current time
count=1
#current_date = datetime.date.today()
#current_day = current_date.strftime("%d%m%Y")
startTime = datetime.now()
current_day = startTime.strftime("%d%m%Y")
stamp=startTime.strftime("%d_%m_%Y_%H_%M_%S")

#deleting and creating DWH folder
#if os.path.exists(DWH_path):
#    shutil.rmtree(DWH_path)
#    os.mkdir(DWH_path)
#else:
#    os.mkdir(DWH_path)


#-----------------------------------------------------------------------------------------------#
#funtion to wirte file
def write_to_file(file_name,row):
    f = open(file_name,'a+')
    writer = csv.writer(f)
    writer.writerow(row)
    f.close()
#-----------------------------------------------------------------------------------------------#


#-----------------------------------------------------------------------------------------------#
def process_row(row):
    global count
    global startTime
    Plus_one = startTime + timedelta(seconds=count)
    start_time=Plus_one.strftime("%Y-%m-%d %H:%M:%S")

    if int(row[6]) == 33 :                   #checking event type 33 for voice
        session_id = str(count) + row[26] + stamp
        row[22] = row[28]  = Resource_value

    elif int(row[6].lstrip('0')) == 35 :                 #checking event type 35 for SMS str(row[9].lstrip('0'))
        #session_id = str(count) + "_SMS_" + stamp
        row[98] = str(count) + row[99] + stamp
        session_id = random.randint(100000, 100000000000)
        row[22] = row[28] = row[35] = Resource_value
        row[57]=0

    elif int(row[6]) == 78 :                 #checking event type 78 for GPRS
        session_id = str(count) + row[26] + stamp
        row[22] = row[28] = row[35] = Resource_value

    elif int(row[6]) == 38 :                 #checking event type 38 for CONTENT/VAS
        session_id = str(count) + row[26] + stamp
        row[22] = row[28] = row[35] = Resource_value

    elif int(row[6]) == 72 :                 #checking event type 72 for MMS
        #session_id = str(count) + row[26] + stamp
        session_id = random.randint(100000, 100000000000)
        row[22] = row[28] = row[35] = Resource_value

    elif int(row[6]) == 87 :                 #checking event type 87 for Soa_Charge_file
        session_id = str(count) + row[26] + stamp
        row[22] = row[28] = row[35] = Resource_value

    elif int(row[6]) == 89 :                 #checking event type 89 for Soa_Replenish_file
        session_id = str(count) + row[26] + stamp
        row[22] = row[28] = row[35] = Resource_value

    row[26] = session_id
    row[8] = start_time
    count += 1
    return row
#-----------------------------------------------------------------------------------------------#

#-----------------------------------------------------------------------------------------------#
############################# Main program start here ##############################

#Resource_value=6283175940087
#Resource_value = raw_input("Enter the Resource value....\n")
Resource_value=sys.argv[1]
start_time=startTime.strftime("%Y-%m-%d %H:%M:%S")
#-----------------------------------------------------------------------------------------------#


#-----------------------------------------------------------------------------------------------#
#Getting list of file names in DWH directories
file_list = []
# r=root, d=directories, f = files
for r, d, f in os.walk(INPUT_path):
    for file in f:
        if '.dat' in file:
            file_list.append(os.path.join(r, file))
#-----------------------------------------------------------------------------------------------#



#-----------------------------------------------------------------------------------------------#
####Processing file by file###
for file in file_list:
    Updated_file_name = DWH_path + "/Sanity_" + stamp + "_" + ntpath.basename(file)
    #print Updated_file_name
    print("Processing the Input file")
    with open(file, 'r') as csv_file:
        data = csv.reader(csv_file)
        for row in data:
            Processed_row=process_row(row)
            write_to_file(Updated_file_name,Processed_row)
    csv_file.close()


print("Running events...............")

#-----------------------------------------------------------------------------------------------#
import subprocess
import shlex
#subprocess.call(shlex.split('./Postpaid_RegSanity_sh sys.argv[1]'))
#Postpaid_RegSanity_sh
#-----------------------------------------------------------------------------------------------#


END_TIME = datetime.now()
print("Start time of Simulator script: " + str(startTime))
print("Finish time of Simulator script " + str(END_TIME))
print("Finish Script")

Result_file_name = "Logs/Result_" + stamp + ".txt"
DWH_file_name = "Logs/DWH_" + stamp + ".txt"
html_file_name = "Result.html"
session_list=[]


prYellow("\n*************************************************************************************")
prGreen("------------------------------------Port Status----------------------------------------")
check_port("Voice",HOST,VOICE_PORT)
check_port("SMS",HOST,SMS_PORT)
check_port("GPRS",HOST,GPRS_PORT)
check_port("UMB",HOST,CONTENT_PORT)
check_port("SOA_Diameter",HOST,SOA_Dia_CHR_PORT)
prYellow("\n*************************************************************************************")


prYellow("\n---------------------------------------Result---------------------------------------------\n")
prPurple("          Session_id                          Req type      Start_time  Result_code")
with open(Result_file_name) as csv_file:
    csv_reader = csv.reader(csv_file,delimiter=',')
    for row in csv_reader:
#       session_list = session_list.append(row[0])
        if row[3] == '2001':
            prGreen(row)
        else:
            prRed(row)

######################HTML Part#######################
line1="""
<html>
<head>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
</style>
</head>
<body>

<h2><font color="blue"><center>RMCC | XL Axiata | Event Sanity Status</center></h2>
<h3><font color="red">Simulator Response:-</font></h3>

<table style="width:60%">
  <tr>
    <th bgcolor="#0080FF" align="center">Session_id</th>
    <th bgcolor="#0080FF" align="center">Request_type</th>
    <th bgcolor="#0080FF" align="center">Start_time</th>
    <th bgcolor="#0080FF" align="center">Result_code</th>
  </tr>
"""
last_line="""
</table>
<br/>
<br/>
<br/>
<br/>
"""

with open(html_file_name,'w') as out:
    out.writelines(line1)
    with open(Result_file_name) as csv_file:
        csv_reader = csv.reader(csv_file,delimiter=',')
        for row in csv_reader:
            Session_id=row[0]
            request_type=row[1]
            Start_time=row[2]
            Result_code=row[3]
            session_list.append(str(Session_id))
            out.write("<tr>")
            out.write("<td align='center'>%s</td>" % Session_id)
            out.write("<td align='center'>%s</td>" % request_type)
            out.write("<td align='center'>%s</td>" % Start_time)
            if row[3] == '2001':
                out.write('<td bgcolor="#00FF00" align="center">%s</td>' % Result_code)
            else:
                out.write('<td bgcolor="#FF0000" align="center">%s</td>' % Result_code)
            out.write("</tr>")
    out.writelines(last_line)
    out.close()

############################### DWH part ######################################

session_list = set(session_list)
Home=os.environ['HOME']
DWH_path=Home + "/var/xlt/projs/apr/interfaces/output/" + current_day  ####change



#funtion to wirte file
def write_temp(file_name,row):
    f = open(file_name,'a+')
    writer = csv.writer(f)
    writer.writerow(row)
    f.close()

####reading the all file names from INPUT dir and storing in files variable as a list

files = []
# r=root, d=directories, f = files
for r, d, f in os.walk(DWH_path):
    #print d
    for file in f:
        if 'DWH' in file and file.endswith(".dat"):
            files.append(os.path.join(r, file))


####Processing file by file###
for f in files:
    #all_event = pd.read_csv(f,encoding = 'unicode_escape',error_bad_lines=False,header=None)
    #print("Reading the CSV file..............\n")
    print(f)
    #print"\n"
    with open(f, 'r') as csv_file:
        data = csv.reader(csv_file)
        for row in data:
            #print row[26]

            for str1 in session_list:
                #print " Check " + str(str1) + " == " + str(row[26])
                if str(str1) in str(row[26]):  #str(row[26].lstrip('0')):
                    write_temp(DWH_file_name,row)

############################### HTML DWH part ######################################
line1="""<h2><font color="red">Charge details from DWH Extract:-</font></h2>

<table style="width:70%">
  <tr>
    <th bgcolor="#0080FF" align="center">Session Id</th>
    <th bgcolor="#0080FF" align="center">Callzone</th>
    <th bgcolor="#0080FF" align="center">Roamzone</th>
    <th bgcolor="#0080FF" align="center">Servicefilter</th>
    <th bgcolor="#0080FF" align="center">Charge Amount</th>
    <th bgcolor="#0080FF" align="center">Charge b4 Allowance</th>
    <th bgcolor="#0080FF" align="center">Allowance Indicator</th>
        <th bgcolor="#0080FF" align="center">Free Units</th>
  </tr>
"""
last_line="""
</table>
</body>
</html>
"""


with open(html_file_name,'a+') as out:
    out.writelines(line1)
    with open(DWH_file_name) as csv_file:
        csv_reader = csv.reader(csv_file,delimiter=',')
        for row in csv_reader:
            Session_id=row[26]
            Callzone=row[50]
            Roamzone=row[54]
            Servicefilter=row[7]
            charge_amt=int(float(row[46]))#row[46]
            chr_b4_allowance=int(float(row[82])) #row[82]
            allowance_id=row[74] #row[74]
            free_unit=int(float(row[40])) #row[40]
            out.write("<tr>")
            out.write("<td align='center'>%s</td>" % Session_id)
            out.write("<td align='center'>%s</td>" % Callzone)
            out.write("<td align='center'>%s</td>" % Roamzone)
            out.write("<td align='center'>%s</td>" % Servicefilter)
            out.write("<td align='center'>%s</td>" % charge_amt)
            out.write("<td align='center'>%s</td>" % chr_b4_allowance)
            out.write("<td align='center'>%s</td>" % allowance_id)
            out.write("<td align='center'>%s</td>" % free_unit)
            out.write("</tr>")
    out.writelines(last_line)
    out.close()
